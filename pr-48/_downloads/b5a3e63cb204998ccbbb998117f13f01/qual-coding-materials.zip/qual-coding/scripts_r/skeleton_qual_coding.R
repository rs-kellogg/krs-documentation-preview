## -----------------------------------------------------------------------------
library(httr)
library(jsonlite)

system_prompt <- readLines("data/system.txt", warn = FALSE) |> paste(collapse = "\n")
model_id <- "anthropic/claude-sonnet-4.6"

# temperature: lowers response variability (0 = most deterministic).
# seed: best-effort reproducibility. Only some models honor it (e.g. OpenAI
# models like openai/gpt-4.1); OpenRouter silently drops it for models that
# don't, including anthropic/claude-sonnet-4.6 — Anthropic's API has no seed
# parameter at all. Neither setting *guarantees* identical output on
# Claude, even at temperature 0 — that's why every row is logged with the
# model_id and coded_at timestamp that actually produced it.
temperature <- 0
seed <- 42

api_key <- Sys.getenv("OPENROUTER_API_KEY")
if (identical(api_key, "")) {
  stop("OPENROUTER_API_KEY is not set. Set it with Sys.setenv() or an .Renviron file before running.")
}

dir.create("outputs", showWarnings = FALSE)
output_path <- "outputs/sample_coded.csv"

# data/sample_input.csv is always the authoritative list of rows (by id).
# If a previous output file exists, its llm_code/model_id/coded_at values
# are merged in by id; any row without a matching previous result (new, or
# missing/deleted from the output) starts as NA and gets (re)coded below.
log_cols <- c("llm_code", "model_id", "coded_at")

input_data <- read.csv("data/sample_input.csv", stringsAsFactors = FALSE)

if (file.exists(output_path)) {
  previous_results <- read.csv(output_path, stringsAsFactors = FALSE)
  carry_cols <- intersect(log_cols, names(previous_results))
  input_data <- merge(input_data, previous_results[, c("id", carry_cols)], by = "id", all.x = TRUE)
  input_data <- input_data[order(input_data$id), ]
  rownames(input_data) <- NULL
}

for (col in log_cols) {
  if (is.null(input_data[[col]])) {
    input_data[[col]] <- NA_character_
  }
}


## -----------------------------------------------------------------------------
# Print the system prompt and one sample user message once, so you can
# eyeball exactly what will be sent before spending any API budget.
cat("===== SYSTEM PROMPT (sent once, shared by every item) =====\n\n")
cat(system_prompt, "\n\n")
cat("===== SAMPLE USER MESSAGE (row 1) =====\n\n")
cat(input_data$text[1], "\n\n")


## -----------------------------------------------------------------------------
code_item <- function(text, system_prompt, model_id, api_key, temperature, seed) {
  body <- list(
    model = model_id,
    temperature = temperature,
    seed = seed,
    messages = list(
      list(role = "system", content = system_prompt),
      list(role = "user", content = text)
    )
  )

  res <- httr::POST(
    url = "https://openrouter.ai/api/v1/chat/completions",
    httr::add_headers(
      "Authorization" = paste("Bearer", api_key),
      "Content-Type" = "application/json"
    ),
    body = jsonlite::toJSON(body, auto_unbox = TRUE)
  )

  if (httr::status_code(res) != 200) {
    return(NA_character_)
  }

  parsed <- jsonlite::fromJSON(httr::content(res, "text", encoding = "UTF-8"), simplifyVector = FALSE)
  trimws(parsed$choices[[1]]$message$content)
}


## -----------------------------------------------------------------------------
for (i in seq_len(nrow(input_data))) {
  if (!is.na(input_data$llm_code[i])) {
    next # already coded in a previous run of this chunk
  }

  input_data$llm_code[i] <- code_item(
    text = input_data$text[i],
    system_prompt = system_prompt,
    model_id = model_id,
    api_key = api_key,
    temperature = temperature,
    seed = seed
  )
  input_data$model_id[i] <- model_id
  input_data$coded_at[i] <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")

  write.csv(input_data, output_path, row.names = FALSE)
  cat(i, "of", nrow(input_data), "coded ->", input_data$llm_code[i], "\n")

  Sys.sleep(1) # basic rate-limiting between requests
}

input_data

