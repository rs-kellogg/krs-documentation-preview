# Setup

The scripts in this folder are:

* `skeleton_qual_coding.R`
* `skeleton_qual_coding.Rmd`

They require R and a small number of R packages.

## Required R packages

Install the required packages once in R:

```r
install.packages(c(
  "httr",
  "jsonlite",
  "rmarkdown"
))
```

The packages are used for:

* `httr` — sending requests to the API
* `jsonlite` — reading and writing JSON
* `rmarkdown` — rendering the `.Rmd` file to HTML

If you are only running `skeleton_qual_coding.R`, `rmarkdown` is not required.

## Add your OpenRouter API key

The scripts read your OpenRouter API key from a local file named `key.txt` in
this `scripts_r` folder.

You can obtain an API key from:

https://openrouter.ai

The downloaded zip includes a blank `scripts_r/key.txt` template. If you are
working from the source repository instead, create that file yourself. Open
`scripts_r/key.txt` and paste your key after the equals sign:

```text
OPENROUTER_API_KEY=sk-or-your-key-here
```

Double quotes are not needed after the equals sign. This is the recommended
format because it is easy to read and matches the variable name used by the API
code.

The script will also accept quotes if you include them by accident:

```text
OPENROUTER_API_KEY="sk-or-your-key-here"
```

If you prefer, the file can also contain only the key itself, with no variable
name:

```text
sk-or-your-key-here
```

Do not put your real API key directly in the R script or commit it to Git. Treat
`key.txt` like a password file if you adapt this example for your own project.

## Run the R script

From the unzipped `qual-coding` folder, run:

```bash
Rscript scripts_r/skeleton_qual_coding.R
```

Alternatively, open the `qual-coding` folder as your RStudio project, then open
`scripts_r/skeleton_qual_coding.R` and run it there.

## Packages needed for the full pipeline

The skeleton scripts above use only the packages listed earlier.

The full pipeline — including Excel files, photos, multiple models, and
reliability statistics — requires several additional packages:

```r
install.packages(c(
  "readxl",
  "writexl",
  "base64enc",
  "irr"
))
```

These packages are used for:

* `readxl` — reading Excel files
* `writexl` — writing Excel files
* `base64enc` — encoding images for API requests
* `irr` — Cohen's kappa and other agreement statistics
