####################################################
# Sample API Call: Calibration by Example (Few-Shot)
####################################################
"""
system prompt / user prompt API call example, this time adding one
hand-coded, genuinely borderline worked example (the Republican Guard case)
to the system prompt from Section 4, so the model calibrates on how you
personally draw the line, not just on the rubric's category names

Before running:
1. pip install openai
2. Save your OpenAI API key in `~/keys/openai-key.txt` (see openai-api guide).
3. Run from this folder: python indonesia_few_shot.py
"""

import json
import os

from openai import OpenAI

openai_key_path = os.path.expanduser("~/keys/openai-key.txt")
groups_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), "../data/groups"))

try:
    with open(openai_key_path, "r") as f:
        api_key = f.read().strip()
except FileNotFoundError:
    raise SystemExit(
        f"Couldn't find {openai_key_path}. Create ~/keys/openai-key.txt in your "
        "home directory and paste your OpenAI API key into it (just the key, "
        "nothing else)."
    )

client = OpenAI(api_key=api_key)

# <<< FOR A NEW STUDY, EDIT THIS BLOCK: swap in your own dimensions and
# labels. Everything below (the rules, the JSON contract) is study-agnostic
# and does not need to change.
RUBRIC_DIMENSIONS = """\
Dimensions and allowed labels (use exactly one label per dimension):
1. Formal integration: state-integrated | ambiguous | non-state-parallel
2. Command & control: state-integrated | ambiguous | non-state-parallel
3. Compensation/loyalty basis: state-integrated | ambiguous | non-state-parallel
"""

SYSTEM_PROMPT = f"""You are a research assistant coding paragraphs about state \
security forces along three dimensions, using the rubric below.

{RUBRIC_DIMENSIONS}
Rules:
- Base every label only on what is stated or clearly implied in the paragraph.
- If the paragraph provides genuinely conflicting or insufficient evidence for \
a dimension, use the "ambiguous" label rather than guessing. Do not force a \
confident label onto a genuinely unclear case.
- For each dimension, provide a one-sentence rationale explaining the label, \
including what specific evidence (or lack of it) drove the call.

Respond ONLY with valid JSON in exactly this shape, no other text:
{{
  "formal_integration": {{"label": "...", "rationale": "..."}},
  "command_control": {{"label": "...", "rationale": "..."}},
  "compensation_basis": {{"label": "...", "rationale": "..."}}
}}
"""

# <<< FOR A NEW STUDY, EDIT THIS BLOCK: replace the paragraph and "Correct
# coding" below with one hand-coded, genuinely borderline example from your
# own data. This is where your personal judgment calls enter the prompt,
# since the rubric text alone can't convey where you draw the line.
CALIBRATION_EXAMPLE = """
Worked example (for calibration only, not part of the dataset):

Paragraph: "The Republican Guard was formally a branch of the national army, \
funded through the defense ministry's budget and holding standard military \
rank. In practice, however, unit commanders were personally appointed by the \
head of state based on kinship and loyalty ties rather than through the \
normal officer promotion system, and several units received supplementary \
payments through informal channels tied directly to the ruling family."

Correct coding:
{
  "formal_integration": {"label": "state-integrated", "rationale": "Formally a branch of the national army, funded through the standard defense budget."},
  "command_control": {"label": "non-state-parallel", "rationale": "Commanders appointed on personal/kinship loyalty rather than through the normal promotion hierarchy."},
  "compensation_basis": {"label": "ambiguous", "rationale": "Base pay follows standard channels, but supplementary informal payments are also described, so neither label fully fits."}
}
"""

SYSTEM_PROMPT_CALIBRATED = SYSTEM_PROMPT + "\n" + CALIBRATION_EXAMPLE

def code_one_file(filepath):
    with open(filepath, "r") as f:
        paragraph = f.read().strip()

    response = client.chat.completions.create(
        model="gpt-5-mini",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT_CALIBRATED},
            {"role": "user", "content": paragraph},
        ],
    )
    return json.loads(response.choices[0].message.content)

result = code_one_file(os.path.join(groups_dir, "indonesia.txt"))
print(json.dumps(result, indent=2))
