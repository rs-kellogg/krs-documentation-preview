#####################################
# Sample API Call: Code a Single File
#####################################
"""
system prompt / user prompt API call example, coding one paragraph
against the rubric from Section 0 (no structured "out" yet)

Before running:
1. pip install openai
2. Save your OpenAI API key in `~/keys/openai-key.txt` (see openai-api guide).
3. Run from this folder: python indonesia_basic_instruct.py
"""

import os

from openai import OpenAI

openai_key_path = os.path.expanduser("~/keys/openai-key.txt")
groups_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), "../data/groups"))

try:
    with open(openai_key_path, "r") as f:
        api_key = f.read().strip()
except FileNotFoundError:
    raise SystemExit(
        f"Couldn't find {openai_key_path}. Create ~/keys/openai-key.txt in your "
        "home directory and paste your OpenAI API key into it (just the key, "
        "nothing else)."
    )

client = OpenAI(api_key=api_key)

SYSTEM_PROMPT = """You are a research assistant coding paragraphs about state \
security forces along three dimensions, using the rubric below.

Dimensions:
1. Formal integration: state-integrated | non-state-parallel
2. Command & control: state-integrated | non-state-parallel
3. Compensation/loyalty basis: state-integrated | non-state-parallel

For each dimension, assign exactly one of the three labels above based only \
on the paragraph provided. Do not use outside knowledge beyond what is stated \
or clearly implied in the text.
"""

def code_one_file(filepath):
    with open(filepath, "r") as f:
        paragraph = f.read().strip()

    response = client.chat.completions.create(
        model="gpt-5-mini",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": paragraph},
        ],
    )
    return response.choices[0].message.content

# Try it on one file first
result = code_one_file(os.path.join(groups_dir, "indonesia.txt"))
print(result)
