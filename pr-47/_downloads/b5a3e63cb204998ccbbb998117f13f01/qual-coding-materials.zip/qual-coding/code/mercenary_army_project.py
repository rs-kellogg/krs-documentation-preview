#################################################
# Sample API Call: Scaling Across the groups/ Folder
#################################################
"""
loops the calibrated system prompt (rubric + Republican Guard worked
example) over every .txt file in groups/, writes one row per group to
coded_groups.csv, and logs call-level metadata (timestamp, model, token
usage) for every API call to api_call_log.csv

Before running:
1. pip install openai pandas
2. Save your OpenAI API key in `~/keys/openai-key.txt` (see openai-api guide).
3. Run from this folder: python mercenary_army_project.py

Note: this makes one API call per file in groups/, so it takes noticeably
longer to run than the single-file scripts. It writes two files:
coded_groups.csv (the coding results) and api_call_log.csv (one row per
API call, with timestamp and model metadata).
"""

import json
import os
from datetime import datetime, timezone

import pandas as pd
from openai import OpenAI

openai_key_path = os.path.expanduser("~/keys/openai-key.txt")
groups_folder_path = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "../data/groups")
)

try:
    with open(openai_key_path, "r") as f:
        api_key = f.read().strip()
except FileNotFoundError:
    raise SystemExit(
        f"Couldn't find {openai_key_path}. Create ~/keys/openai-key.txt in your "
        "home directory and paste your OpenAI API key into it (just the key, "
        "nothing else)."
    )

client = OpenAI(api_key=api_key)

# <<< FOR A NEW STUDY, EDIT THIS BLOCK: swap in your own dimensions and
# labels. Everything below (the rules, the JSON contract) is study-agnostic
# and does not need to change.
RUBRIC_DIMENSIONS = """\
Dimensions and allowed labels (use exactly one label per dimension):
1. Formal integration: state-integrated | ambiguous | non-state-parallel
2. Command & control: state-integrated | ambiguous | non-state-parallel
3. Compensation/loyalty basis: state-integrated | ambiguous | non-state-parallel
"""

SYSTEM_PROMPT = f"""You are a research assistant coding paragraphs about state \
security forces along three dimensions, using the rubric below.

{RUBRIC_DIMENSIONS}
Rules:
- Base every label only on what is stated or clearly implied in the paragraph.
- If the paragraph provides genuinely conflicting or insufficient evidence for \
a dimension, use the "ambiguous" label rather than guessing. Do not force a \
confident label onto a genuinely unclear case.
- For each dimension, provide a one-sentence rationale explaining the label, \
including what specific evidence (or lack of it) drove the call.

Respond ONLY with valid JSON in exactly this shape, no other text:
{{
  "formal_integration": {{"label": "...", "rationale": "..."}},
  "command_control": {{"label": "...", "rationale": "..."}},
  "compensation_basis": {{"label": "...", "rationale": "..."}}
}}
"""

# <<< FOR A NEW STUDY, EDIT THIS BLOCK: replace the paragraph and "Correct
# coding" below with one hand-coded, genuinely borderline example from your
# own data. This is where your personal judgment calls enter the prompt,
# since the rubric text alone can't convey where you draw the line.
CALIBRATION_EXAMPLE = """
Worked example (for calibration only, not part of the dataset):

Paragraph: "The Republican Guard was formally a branch of the national army, \
funded through the defense ministry's budget and holding standard military \
rank. In practice, however, unit commanders were personally appointed by the \
head of state based on kinship and loyalty ties rather than through the \
normal officer promotion system, and several units received supplementary \
payments through informal channels tied directly to the ruling family."

Correct coding:
{
  "formal_integration": {"label": "state-integrated", "rationale": "Formally a branch of the national army, funded through the standard defense budget."},
  "command_control": {"label": "non-state-parallel", "rationale": "Commanders appointed on personal/kinship loyalty rather than through the normal promotion hierarchy."},
  "compensation_basis": {"label": "ambiguous", "rationale": "Base pay follows standard channels, but supplementary informal payments are also described, so neither label fully fits."}
}
"""

SYSTEM_PROMPT_CALIBRATED = SYSTEM_PROMPT + "\n" + CALIBRATION_EXAMPLE

def code_one_file(filepath):
    """Codes one paragraph and returns (result, metadata) for that call."""
    with open(filepath, "r") as f:
        paragraph = f.read().strip()

    # Local wall-clock time right when the call is sent.
    call_timestamp = datetime.now().astimezone().isoformat(timespec="seconds")

    response = client.chat.completions.create(
        model="gpt-5-mini",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT_CALIBRATED},
            {"role": "user", "content": paragraph},
        ],
    )

    # Metadata about the call itself, pulled from the API response object.
    metadata = {
        "call_timestamp": call_timestamp,
        "model_requested": "gpt-5-mini",
        "model_returned": response.model,
        "response_id": response.id,
        "api_created_utc": datetime.fromtimestamp(
            response.created, tz=timezone.utc
        ).isoformat(timespec="seconds"),
        "prompt_tokens": response.usage.prompt_tokens,
        "completion_tokens": response.usage.completion_tokens,
        "total_tokens": response.usage.total_tokens,
    }

    result = json.loads(response.choices[0].message.content)
    return result, metadata

def code_folder(folder_path):
    rows = []
    log_rows = []
    for filename in sorted(os.listdir(folder_path)):
        if not filename.endswith(".txt"):
            continue
        group_name = filename.replace(".txt", "")
        filepath = os.path.join(folder_path, filename)

        print(f"Coding {group_name}...")
        result, metadata = code_one_file(filepath)

        rows.append({
            "group": group_name,
            "formal_integration_label": result["formal_integration"]["label"],
            "formal_integration_rationale": result["formal_integration"]["rationale"],
            "command_control_label": result["command_control"]["label"],
            "command_control_rationale": result["command_control"]["rationale"],
            "compensation_basis_label": result["compensation_basis"]["label"],
            "compensation_basis_rationale": result["compensation_basis"]["rationale"],
        })

        log_rows.append({"group": group_name, **metadata})

    return pd.DataFrame(rows), pd.DataFrame(log_rows)

df, log_df = code_folder(groups_folder_path)
df.to_csv("coded_groups.csv", index=False)
log_df.to_csv("api_call_log.csv", index=False)
print(df)
print(log_df)
