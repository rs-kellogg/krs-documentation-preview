#################
# Sample API Call
##################
"""
system prompt / user prompt API call example

Before running:
1. pip install openai
2. Save your OpenAI API key in `~/keys/openai-key.txt` (see openai-api guide).
3. Run: python api_call_ex.py
"""

import os

from openai import OpenAI

openai_key_path = os.path.expanduser("~/keys/openai-key.txt")

try:
    with open(openai_key_path, "r") as f:
        api_key = f.read().strip()
except FileNotFoundError:
    raise SystemExit(
        f"Couldn't find {openai_key_path}. Create ~/keys/openai-key.txt in your "
        "home directory and paste your OpenAI API key into it (just the key, "
        "nothing else)."
    )

client = OpenAI(api_key=api_key)

response = client.chat.completions.create(
    model="gpt-5-mini",
    messages=[
        {"role": "system", "content": "You are a die-hard Cardinals fan who believes in heated team rivalries. You are taking a survey."},
        {"role": "user", "content": "What's your honest opinion of the Cubs?"},
    ],
)

print(response.choices[0].message.content)
